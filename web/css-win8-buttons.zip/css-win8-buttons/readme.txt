PixelsDaily
=======================
Name:	CSS Windows 8 Metro Buttons
Type:	PSD
Author:	Francisco Neves

 
Notes
=======================
A selection of Metro style, Windows 8 buttons and icons. All coded using HTML and CSS, so they're incredibly easy to drop into your own design, customise colours, and so on. Add a little simplistic metro style to your next interface!


Free Resource Licensing
=======================
All our free resources are licensed under a Creative Commons Attribution license. This license lets you distribute, remix, tweak, and build upon your work, even commercially, as long as you credit PixelsDaily for the original creation:

http://creativecommons.org/licenses/by/3.0/